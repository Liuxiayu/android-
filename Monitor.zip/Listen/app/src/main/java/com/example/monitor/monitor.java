package com.example.monitor;


import android.app.Activity;
import android.view.View;
import android.widget.EditText;

public class monitor implements View.OnClickListener
{
    private Activity activity;
    public monitor(Activity activity)
    {
        this.activity = activity;
    }
    @Override
    public void onClick(View v)
    {
        EditText txt = activity.findViewById(R.id.txt);
        txt.setText("外部类被点击了！");
    }
}
